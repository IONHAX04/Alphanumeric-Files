//CREATING ARRAY AND PASSING NUMBER,QNS, OPTIONS & ANSWERS
let questions=[
	{
		number: 1,
		question : "What is HTML?",
		answer: "All of the mentioned",
		options:[
			"Describes the structuer of a webpage",
			"Standard markup language to create web page",
			"Consist of a set of elements helps to view content",
			"All of the mentioned"
		]
	},
	{
		number:2,
		question : "Who is the father of HTML?",
		answer: "Tim Berners-Lee",
		options:[
			"Rasmus Lerdorf",
			"Tim Berners-Lee",
			"Brendan Eich",
			"Sergey Brin"
		]
	},
	{
		number:3,
		question : "HTML stands for____",
		answer: "Hyper Text Markup Language",
		options:[
			"Hyper Text Markup Language",
			"Hyper Text Machine Language",
			"Hyper Text Marking Language",
			"Hyper Text Marking Language"
		]
	},
	{
		number:4,
		question : "Which of the following is not the element associated with the HTML table layout?",
		answer: "color",
		options:[
			"alignment",
			"color",
			"size",
			"spanning"
		]
	},
	{
		number:5,
		question : "Which of the following is used to read an HTML page and render it?",
		answer: "Web Browser",
		options:[
			"Web Server",
			"Web Network",
			"Web Browser",
			"Web Matrix"
		]
	},
	{
		number:6,
		question : "Which of the following is not a difference between HTML and XHTML?",
		answer: "Charset in both html and xhtml is text/html",
		options:[
			"Charset in both html and xhtml is text/html",
			"Tags and attributes are case-insensitive in HTML but not in XHTML",
			"Special characters must be escaped using character entities in XHTML unlike HTML",
			"None of the above"
		]
	},
	{
		number:7,
		question : "Which of the following tag is used for inserting the largest heading in HTML?",
		answer: "<h1>",
		options:[
			"head",
			"h1",
			"h6",
			"heading"
		]
	},
	{
		number:8,
		question : " What is DOM in HTML?",
		answer: "Convention for representing and interacting with objects in html documents",
		options:[
			"Language dependent application programming",
			"Hierarchy of objects in ASP.NET",
			"Application programming interface",
			"Convention for representing and interacting with objects in html documents"
		]
	},
	{
		number:9,
		question : "In which part of the HTML metadata is contained?",
		answer: "head tag",
		options:[
			"head tag",
			"title tag",
			"html tag",
			"body tag"
		]
	},
	{
		number:10,
		question : "Which element is used to get highlighted text in HTML5?",
		answer: "mark",
		options:[
			"u",
			"highlight",
			"mark",
			"b"
		]
	},


]